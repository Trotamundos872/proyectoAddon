package com.example.demo.proyectoAddons.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.proyectoAddons.model.Addon;
import com.example.demo.proyectoAddons.repository.AddonRepository;

/**
 * Pruebas de Integración para AddonController
 * Prueba básica de endpoints
 */
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@DisplayName("Pruebas de Integración de AddonController")
class AddonControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private AddonRepository addonRepository;

    private Addon testAddon;

    @BeforeEach
    void setUp() {
        // Crear un addon de prueba
        testAddon = new Addon();
        testAddon.setNombre("Addon de Prueba");
        testAddon.setTipo("Plugin");
        testAddon.setUrlMiniatura("https://example.com/imagen.png");
        testAddon.setDescripcion("Este esdgdghkudhgoisdjfoipsjgposjdfposjdfposdfgdgsfgsdgdghkudhgoisdjfoipsjgposjdfposjddgdghkudhgoisdjfoipsjgposjdfposjdfposddgdghkudhgoisdjfoipsjgposjdfposjdfposddgdghkudhgoisdjfoipsjgposjdfposjdfposddgdghkudhgoisdjfoipsjgposjdfposjdfposdfposdfposjdfueba para las pruebas de integración");
        testAddon.setLikes(0);
        testAddon = addonRepository.save(testAddon);
    }

    @Test
    @DisplayName("Obtener todos los addons - GET /api/addon")
    void testGetAllAddons() throws Exception {
        mockMvc.perform(get("/api/addon"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Obtener creadores de un addon")
    void testGetCreadoresDeAddon() throws Exception {
        mockMvc.perform(get("/api/addon/creadores/" + testAddon.getId()))
                .andExpect(status().isOk());
    }

@Test
    @DisplayName("Obtener addon por ID")
    void testGetAddonById() throws Exception {
        mockMvc.perform(get("/api/addon/" + testAddon.getId()))
                .andExpect(status().isOk());
    }
}


